exports.handler = function(event, context, callback) {
    var res ={
        "statusCode": 200,
        "headers": {
            "Content-Type": "*/*"
        }
    };
    res.body = JSON.parse(event.input.body);
    uploadFileOnS3(res.body, "myfile_"+getTime());
    callback(null, res);
};

//###

function getTime(){
    
    var createdDatetime= new Date(decodeURIComponent('2019-06-22T18%3A20%3A42%2B00%3A00'))
    var date=new Date(1561231242 * 1000);
    var date_utc=new Date(1561227642 * 1000);
    
    console.log(createdDatetime, date, date_utc);
    
    const theDate = new Date();
    const day = theDate.getUTCDate();
    const month = theDate.getUTCMonth()+1;
    const twoDigitMonth = month<10? "0" + month: month;
    const twoDigitYear = theDate.getUTCFullYear().toString().substr(2);
    const hours = theDate.getUTCHours();
    const mins = theDate.getUTCMinutes();
    const seconds = theDate.getUTCSeconds();
    const formattedDate = `${day}${twoDigitMonth}${twoDigitYear}-${hours}${mins}${seconds}`;
    
    console.log(formattedDate);
    return formattedDate;
}

//###

const aws = require('aws-sdk');
const s3 = new aws.S3({ apiVersion: '2006-03-01' });

async function uploadFileOnS3(fileData, fileName){
    let s3bucket = process.env.s3bucket
    const params = {
        Bucket:  s3bucket,
        Key: fileName,
        Body: JSON.stringify(fileData),
    };

    try {
        const response = await s3.upload(params).promise();
        console.log('Response: ', response);
        return response;

    } catch (err) {
        console.log(err);
    }
};